import React from 'react';

const Checkout = () => {
  console.log("Checkout Page Rendered"); // Debugging log

  return (
    <div>
      <h2>Checkout Page</h2>
    </div>
  );
};

export default Checkout;
